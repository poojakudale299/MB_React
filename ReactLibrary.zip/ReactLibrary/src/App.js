import "./App.css";
import NavBar from "./components/Navbar";
import Nav from "./components/Nav"
import Home from "./components/Home";
import AboutUs from "./components/AboutUs";
import MovieCarousel from "./components/Carousel";
import NavFooter from "./components/NavFooter";
import Movies from "./components/Movies";
// import { Navbar, Nav, Container, NavDropdown, Button } from "react-bootstrap";

// function App() {
//   let page = window.location.pathname;

//   if (page === "/about") return <AboutUs />;
//   return (
//     <div id="App">
//       <NavBar />
//       <MovieCarousel />
//       <Home />
//       <Movies />
//       <NavFooter />
//       <AboutUs />
//     </div>
//   );
// }

import { Route, Switch, Redirect } from "react-router-dom";
// import NavFooter from "./Common/NavFooter";
// import Home from "./Home/Home";
// import Contact from "./Contact/Contact";
// import About from "./About/About";
import PgNotFound from "./components/PgNotFound";
// import Movies from "./Movies/Movies";
import MovieDetail from "./components/MovieDetail";

function App(props) {
  return (
    <div className="container-fluid">
      <Nav />
      <Switch>
        <Route path="/" exact component={Home} />
        <Route path="/movies" component={Movies} />
        <Route path="/movie/:slug" component={MovieDetail} />
        <Route path="/about" component={AboutUs} />
        <Redirect from="/olpg" to="contact" />
        <Route component={PgNotFound} />
      </Switch>
      <NavFooter />
    </div>
  );
}


export default App;
